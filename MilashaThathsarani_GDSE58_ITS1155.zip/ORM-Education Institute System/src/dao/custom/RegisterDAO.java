package dao.custom;

import dao.SuperDAO;
import entity.Registration;

public interface RegisterDAO extends SuperDAO<Registration,String> {
    boolean ifRegisterExist(String registerId);
}
