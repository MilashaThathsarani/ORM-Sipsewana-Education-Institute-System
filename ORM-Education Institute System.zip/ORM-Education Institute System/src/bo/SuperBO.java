package bo;

import entity.Student;

public interface SuperBO {

}
