package controller;

public class ViewStudentDetailsController {
}
