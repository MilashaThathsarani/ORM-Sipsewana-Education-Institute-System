package entity;

import java.io.Serializable;

public interface SuperEntity extends Serializable {
}
