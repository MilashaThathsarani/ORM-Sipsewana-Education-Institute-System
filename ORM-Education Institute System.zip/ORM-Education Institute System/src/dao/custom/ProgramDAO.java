package dao.custom;

import dao.SuperDAO;
import entity.Program;

public interface ProgramDAO extends SuperDAO<Program,String> {
}
