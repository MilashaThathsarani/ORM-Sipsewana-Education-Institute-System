package dao.custom;

import bo.SuperBO;
import dao.SuperDAO;
import dto.StudentDTO;
import entity.Student;

public interface StudentDAO extends SuperDAO<Student,String> {

}
