package dao.custom;

import dao.SuperDAO;
import entity.RegisterDetail;

public interface RegisterDetailDAO extends SuperDAO<RegisterDetail,String> {
}
